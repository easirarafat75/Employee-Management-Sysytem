#include "stdafx.h"
#include "Stack.h"
#include <iostream>
#include <string>
#pragma warning(disable:4996)
using namespace std;

struct employee
{
	int id;
	char fName[256], lName[256], position[256], pNo[256];
	struct employee *NEXT;
}*START_S, *CURRENT_S;

Stack::Stack()
{
	FILE *fptr = fopen("employee.txt", "rb+");
	if (fptr == NULL) //if file does not exist, create it
	{
		fptr = fopen("employee.txt", "wb");
		fclose(fptr);
	}
	else
		fclose(fptr);
	//Load text file to the list
	FILE* file = fopen("employee.txt", "r");
	char line[1024];
	char *p;
	START_S = CURRENT_S = NULL;
	int lastId = 0;
	while (fgets(line, sizeof(line), file))
	{
		p = strtok(line, "@");
		lastId= atoi(p);
		if (lastId > hId)
			hId = lastId;
		p = strtok(NULL, "@");
		string fName(p);
		p = strtok(NULL, "@");
		string lName(p);
		p = strtok(NULL, "@");
		string position(p);
		p = strtok(NULL, "@");
		string pNo(p);
		if (START_S == NULL)
		{
			START_S = CURRENT_S = (struct employee *)malloc(sizeof(struct employee));
			CURRENT_S->id = lastId;
			strcpy(CURRENT_S->fName, fName.c_str());
			strcpy(CURRENT_S->lName, lName.c_str());
			strcpy(CURRENT_S->position, position.c_str());
			strcpy(CURRENT_S->pNo, pNo.c_str());
			CURRENT_S->NEXT = NULL;
		}
		else
		{
			while (CURRENT_S->NEXT)
			{
				CURRENT_S = CURRENT_S->NEXT;
			}
			struct employee *NEWNODE;
			NEWNODE = (struct employee *)malloc(sizeof(struct employee));
			CURRENT_S->NEXT = NEWNODE;
			CURRENT_S = CURRENT_S->NEXT;
			CURRENT_S->id = lastId;
			strcpy(CURRENT_S->fName, fName.c_str());
			strcpy(CURRENT_S->lName, lName.c_str());
			strcpy(CURRENT_S->position, position.c_str());
			strcpy(CURRENT_S->pNo, pNo.c_str());
			CURRENT_S->NEXT = NULL;
		}
	}

}
void Stack::addEmployee()
{
	string fName, lName, position, pNo;
	hId++;
	cout << endl << "---Add Employee---";
	cout << endl << "First Name: ";
	cin >> fName;
	cout << endl << "Last Name: ";
	cin >> lName;
	cout <<endl<< "Postion: ";
	cin >> position;
	cout <<endl<< "Phone Number: ";
	cin >> pNo;
	CURRENT_S=START_S;
	if (START_S == NULL)
	{
		START_S = CURRENT_S = (struct employee *)malloc(sizeof(struct employee));
		CURRENT_S->id = hId;
		strcpy(CURRENT_S->fName, fName.c_str());
		strcpy(CURRENT_S->lName, lName.c_str());
		strcpy(CURRENT_S->position, position.c_str());
		strcpy(CURRENT_S->pNo, pNo.c_str());
		CURRENT_S->NEXT = NULL;
	}
	else
	{
		while (CURRENT_S->NEXT)
		{
			CURRENT_S = CURRENT_S->NEXT;
		}
		struct employee *NEWNODE;
		NEWNODE = (struct employee *)malloc(sizeof(struct employee));
		CURRENT_S->NEXT = NEWNODE;
		CURRENT_S = CURRENT_S->NEXT;
		CURRENT_S->id = hId;
		strcpy(CURRENT_S->fName, fName.c_str());
		strcpy(CURRENT_S->lName, lName.c_str());
		strcpy(CURRENT_S->position, position.c_str());
		strcpy(CURRENT_S->pNo, pNo.c_str());
		CURRENT_S->NEXT = NULL;
	}
	cout << endl << "The New Employee Has Been Added Successfully." << endl;
	system("pause");
}
void Stack::deleteEmployee()
{
	int sId;
	cout << endl << "---Delete Employee---";
	cout << endl << "Please Insert The Id Of Employee To Delete: ";
	cin >> sId;
	CURRENT_S = START_S;
	if (START_S == NULL)
	{
		cout << endl << "There Is No Employee With Inserted ID " << endl;
		system("pause");
		return;
	}
	if (START_S->id == sId)
	{
		START_S = START_S->NEXT;
		free(CURRENT_S);
		cout << endl << "The Employee With Inserted ID Has Been Deleted" << endl;
		system("pause");
		return;
	}
	while (CURRENT_S)
	{
		if (CURRENT_S->NEXT->id == sId)
		{
			struct employee *TEMP= CURRENT_S->NEXT;
			CURRENT_S->NEXT = CURRENT_S->NEXT->NEXT;
			free(TEMP);
			cout << endl << "The Employee With Inserted ID Has Been Deleted" << endl;
			system("pause");
			return;
		}
		CURRENT_S = CURRENT_S->NEXT;
	}
	cout << endl << "There Is No Employee With Inserted ID " << endl;
	system("pause");
	return;
}
void Stack::sort()
{
	bool unsorted = true;
	while (unsorted) {
		unsorted = false;
		CURRENT_S = START_S;

		while (CURRENT_S->NEXT != NULL) {
			if (CURRENT_S->NEXT->fName[0] < CURRENT_S->fName[0]) {
				struct employee *TEMP = CURRENT_S->NEXT;
				swap(CURRENT_S->id, CURRENT_S->NEXT->id);
				swap(CURRENT_S->fName, CURRENT_S->NEXT->fName);
				swap(CURRENT_S->lName, CURRENT_S->NEXT->lName);
				swap(CURRENT_S->position, CURRENT_S->NEXT->position);
				swap(CURRENT_S->pNo, CURRENT_S->NEXT->pNo);
		
					unsorted = true;
			}

			CURRENT_S = CURRENT_S->NEXT;
		}
	}
	cout << endl << "The Employee List Has Been Sorted " << endl;
	system("pause");
}
void Stack::updateEmployee()
{
	int sId;
	cout << endl << "---Search Employee---";
	cout << endl << "Please Insert The Id Of Employee To update: ";
	cin >> sId;
	CURRENT_S = START_S;
	if (START_S == NULL)
	{
		cout << endl << "There Is No Employee With Inserted ID " << endl;
		system("pause");
		return;
	}
	while (CURRENT_S)
	{
		if (CURRENT_S->id == sId)
		{
			cout << endl << "Employee Id: " << CURRENT_S->id << endl
				<< "First Name: " << CURRENT_S->fName << endl
				<< "Last Name: " << CURRENT_S->lName << endl
				<< "Positon: " << CURRENT_S->position << endl
				<< "Phone Number: " << CURRENT_S->pNo << endl;
			cout << "Please Entere New Data" << endl;
			cout << endl << "First Name: ";
			cin >> CURRENT_S->fName;
			cout << endl << "Last Name: ";
			cin >> CURRENT_S->lName;
			cout << endl << "Postion: ";
			cin >> CURRENT_S->position;
			cout << endl << "Phone Number: ";
			cin >> CURRENT_S->pNo;
			cout << endl << "The Employee's Details Have Been Updated." << endl;
			system("pause");
			return;
		}
		CURRENT_S = CURRENT_S->NEXT;
	}
	cout << endl << "There Is No Employee With Inserted ID " << endl;
	system("pause");
	return;
}
void Stack::displayEmployee()
{
	cout << endl << "---Display Employee---";
	CURRENT_S = START_S;
	if (START_S == NULL)
	{
		cout << endl << "There Is No Employee To Display" << endl;
		system("pause");
		return;
	}
	while (CURRENT_S)
	{
			cout << endl<<CURRENT_S->id << " / "
			<< CURRENT_S->fName << " / "
			<< CURRENT_S->lName << " / "
			<< CURRENT_S->position << " / "
			<< CURRENT_S->pNo ;
			
		CURRENT_S = CURRENT_S->NEXT;
	}
	cout << endl;
	system("pause");
	return;
}
void Stack::searchEmoloyee()
{
	int sId;
	cout << endl << "---Update Employee---";
	cout << endl << "Please Insert The Id Of Employee To Search: ";
	cin >> sId;
	CURRENT_S = START_S;
	if (START_S == NULL)
	{
		cout << endl << "There Is No Employee With Inserted ID " << endl;
		system("pause");
		return;
	}
	while (CURRENT_S)
	{
		if (CURRENT_S->id == sId)
		{
			cout << endl << "Employee Id: " << CURRENT_S->id << endl
				<< "First Name: " << CURRENT_S->fName << endl
				<< "Last Name: " << CURRENT_S->lName << endl
				<< "Positon: " << CURRENT_S->position << endl
				<< "Phone Number: " << CURRENT_S->pNo << endl;

			system("pause");
			return;
		}
		CURRENT_S = CURRENT_S->NEXT;
	}
	cout << endl << "There Is No Employee With Inserted ID " << endl;
	system("pause");
	return;
}
void Stack::clearAllEmployee()
{
	CURRENT_S = START_S;
	if (START_S == NULL)
	{
		cout << endl << "All Employees Are Removed" << endl;
		system("pause");
		return;
	}
	while (CURRENT_S->NEXT)
	{
		START_S = CURRENT_S->NEXT;
		free(CURRENT_S);
		CURRENT_S = START_S;
	}
	if (START_S)
		free(START_S);
	START_S = CURRENT_S = NULL;
	cout << endl << "All Employees Are Removed" << endl;
	system("pause");
	return;
}

Stack::~Stack()
{
	FILE* file = fopen("employee.txt", "w");
	CURRENT_S = START_S;
	while (CURRENT_S)
	{
		fprintf(file, "%d@%s@%s@%s@%s",CURRENT_S->id, CURRENT_S->fName, CURRENT_S->lName, CURRENT_S->position, CURRENT_S->pNo);
		CURRENT_S = CURRENT_S->NEXT;
	}
	fclose(file);
}
