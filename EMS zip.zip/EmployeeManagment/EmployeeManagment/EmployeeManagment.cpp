// EmployeeManagment.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include "Stack.h"
#include "Queue.h"
using namespace std;

bool login();
int main()
{
	cout << "------------EMPLOYEE MANAGMNET SYSTEM-------------" << endl << endl;
	if (!login())
		return 0;
	
	int stru = 0;
	while (true)
	{
		cout << endl << "Do You Want To Use 1.Stack vs 2.Queue(1-2)";
		cin >> stru;
		if (stru == 1 || stru == 2)
			break;
	}
	if (stru == 1)
	{
		Stack *oStack=new Stack();
		while (true)
		{
			string sel = "0";
			cout << endl<<endl << "1.Add new employee" << endl
				<< "2.Delete employee" << endl
				<< "3.Search for an employee" << endl
				<< "4.Update employee details" << endl
				<< "5.Sort employee by name" << endl
				<< "6.Display all employee" << endl
				<< "7.Clear all employee"<<endl
				<< "8.Exit"<<endl
				<< "Please Select From Menu(1-8): ";
			cin >> sel;
			if (sel == "1")
				oStack->addEmployee();
			if (sel == "2")
				oStack->deleteEmployee();
			else if (sel == "3")
				oStack->searchEmoloyee();
			else if (sel == "4")
				oStack->updateEmployee();
			else if (sel == "5")
				oStack->sort();
			else if (sel == "6")
				oStack->displayEmployee();
			else if (sel == "7")
				oStack->clearAllEmployee();
			else if (sel == "8")
			{
				delete oStack;
				return 0;
			}
		}
	}
	else
	{
		Queue *oQueue=new Queue();
		while (true)
		{
			string sel = "0";
			cout << endl << endl << "1.Add new employee" << endl
				<< "2.Delete employee" << endl
				<< "3.Search for an employee" << endl
				<< "4.Update employee details" << endl
				<< "5.Sort employee by name" << endl
				<< "6.Display all employee" << endl
				<< "7.Clear all employee" << endl
				<< "8.Exit" << endl
				<< "Please Select From Menu(1-8): ";
			cin >> sel;
			if (sel == "1")
				oQueue->addEmployee();
			if (sel == "2")
				oQueue->deleteEmployee();
			else if (sel == "3")
				oQueue->searchEmoloyee();
			else if (sel == "4")
				oQueue->updateEmployee();
			else if (sel == "6")
				oQueue->displayEmployee();
			else if (sel == "7")
				oQueue->clearAllEmployee();
			else if (sel == "8")
				return 0;
		}
	}
    return 0;
}
bool login()
{
	while (true)
	{
		string userName, passwor;
		cout <<endl<< "Please Insert UserName:";
		cin >> userName;
		cout << endl << "Please Inset Password:";
		cin >> passwor;
		if (userName != "admin" || passwor != "admin")
		{
			cout << endl << "Wrong UserName Or Password, Do you want to try Again(y/n)";
			string ans;
			cin >> ans;
			if (ans == "n")
				return false;
		}
		else
		{
			return true;
		}
	}
}

