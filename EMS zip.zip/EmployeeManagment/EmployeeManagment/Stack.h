#pragma once
class Stack
{
public:
	Stack();
	~Stack();
	void addEmployee();
	void deleteEmployee();
	void searchEmoloyee();
	void updateEmployee();
	void displayEmployee();
	void clearAllEmployee();
	void sort();
private:
	int hId = 0;
};

