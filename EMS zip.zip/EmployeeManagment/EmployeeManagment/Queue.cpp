#include "stdafx.h"
#include "Queue.h"
#include <iostream>
#include <string>
#pragma warning(disable:4996)
using namespace std;
struct employee
{
	int id;
	char fName[256], lName[256], position[256], pNo[256];
	struct employee *NEXT;
}*START_Q, *CURRENT_Q;

Queue::Queue()
{
	FILE *fptr = fopen("employee.txt", "rb+");
	if (fptr == NULL) //if file does not exist, create it
	{
		fptr = fopen("employee.txt", "wb");
		fclose(fptr);
	}
	else
		fclose(fptr);
	//Load text file to the list
	FILE* file = fopen("employee.txt", "r");
	char line[1024];
	char *p;
	START_Q = CURRENT_Q = NULL;
	int lastId = 0;
	while (fgets(line, sizeof(line), file))
	{
		p = strtok(line, "@");
		lastId = atoi(p);
		if (lastId > hId)
			hId = lastId;
		p = strtok(NULL, "@");
		string fName(p);
		p = strtok(NULL, "@");
		string lName(p);
		p = strtok(NULL, "@");
		string position(p);
		p = strtok(NULL, "@");
		string pNo(p);
		if (START_Q == NULL)
		{
			START_Q = CURRENT_Q = (struct employee *)malloc(sizeof(struct employee));
			CURRENT_Q->id = lastId;
			strcpy(CURRENT_Q->fName, fName.c_str());
			strcpy(CURRENT_Q->lName, lName.c_str());
			strcpy(CURRENT_Q->position, position.c_str());
			strcpy(CURRENT_Q->pNo, pNo.c_str());
			CURRENT_Q->NEXT = NULL;
		}
		else
		{
			struct employee *NEWNODE;
			NEWNODE = (struct employee *)malloc(sizeof(struct employee));
			CURRENT_Q->NEXT = START_Q;
			START_Q = NEWNODE;
			CURRENT_Q->id = lastId;
			strcpy(CURRENT_Q->fName, fName.c_str());
			strcpy(CURRENT_Q->lName, lName.c_str());
			strcpy(CURRENT_Q->position, position.c_str());
			strcpy(CURRENT_Q->pNo, pNo.c_str());
			
		}
	}

}
void Queue::addEmployee()
{
	string fName, lName, position, pNo;
	hId++;
	cout << endl << "---Add Employee---";
	cout << endl << "First Name: ";
	cin >> fName;
	cout << endl << "Last Name: ";
	cin >> lName;
	cout << endl << "Postion: ";
	cin >> position;
	cout << endl << "Phone Number: ";
	cin >> pNo;
	START_Q = CURRENT_Q = NULL;
	if (START_Q == NULL)
	{
		START_Q = CURRENT_Q = (struct employee *)malloc(sizeof(struct employee));
		CURRENT_Q->id = hId;
		strcpy(CURRENT_Q->fName, fName.c_str());
		strcpy(CURRENT_Q->lName, lName.c_str());
		strcpy(CURRENT_Q->position, position.c_str());
		strcpy(CURRENT_Q->pNo, pNo.c_str());
		CURRENT_Q->NEXT = NULL;
	}
	else
	{
		struct employee *NEWNODE;
		NEWNODE = (struct employee *)malloc(sizeof(struct employee));
		CURRENT_Q->NEXT = START_Q;
		START_Q = NEWNODE;
		CURRENT_Q->id = hId;
		strcpy(CURRENT_Q->fName, fName.c_str());
		strcpy(CURRENT_Q->lName, lName.c_str());
		strcpy(CURRENT_Q->position, position.c_str());
		strcpy(CURRENT_Q->pNo, pNo.c_str());

	}
	cout << endl << "The New Employee Has Been Added Successfully." << endl;
	system("pause");
}
void Queue::sort()
{
	bool unsorted = true;
	while (unsorted) {
		unsorted = false;
		CURRENT_Q = START_Q;

		while (CURRENT_Q->NEXT != NULL) {
			if (CURRENT_Q->NEXT->fName[0] < CURRENT_Q->fName[0]) {
				struct employee *TEMP = CURRENT_Q->NEXT;
				swap(CURRENT_Q->id, CURRENT_Q->NEXT->id);
				swap(CURRENT_Q->fName, CURRENT_Q->NEXT->fName);
				swap(CURRENT_Q->lName, CURRENT_Q->NEXT->lName);
				swap(CURRENT_Q->position, CURRENT_Q->NEXT->position);
				swap(CURRENT_Q->pNo, CURRENT_Q->NEXT->pNo);

				unsorted = true;
			}

			CURRENT_Q = CURRENT_Q->NEXT;
		}
	}
	cout << endl << "The Employee List Has Been Sorted " << endl;
	system("pause");
}
void Queue::deleteEmployee()
{
	int sId;
	cout << endl << "---Delete Employee---";
	cout << endl << "Please Insert The Id Of Employee To Delete: ";
	cin >> sId;
	CURRENT_Q = START_Q;
	if (START_Q == NULL)
	{
		cout << endl << "There Is No Employee With Inserted ID " << endl;
		system("pause");
		return;
	}
	if (START_Q->id == sId)
	{
		START_Q = START_Q->NEXT;
		free(CURRENT_Q);
		cout << endl << "The Employee With Inserted ID Has Been Deleted" << endl;
		system("pause");
		return;
	}
	while (CURRENT_Q)
	{
		if (CURRENT_Q->NEXT->id == sId)
		{
			struct employee *TEMP = CURRENT_Q->NEXT;
			CURRENT_Q->NEXT = CURRENT_Q->NEXT->NEXT;
			free(TEMP);
			cout << endl << "The Employee With Inserted ID Has Been Deleted" << endl;
			system("pause");
			return;
		}
		CURRENT_Q = CURRENT_Q->NEXT;
	}
	cout << endl << "There Is No Employee With Inserted ID " << endl;
	system("pause");
	return;
}
void Queue::updateEmployee()
{
	int sId;
	cout << endl << "---Search Employee---";
	cout << endl << "Please Insert The Id Of Employee To Update: ";
	cin >> sId;
	CURRENT_Q = START_Q;
	if (START_Q == NULL)
	{
		cout << endl << "There Is No Employee With Inserted ID " << endl;
		system("pause");
		return;
	}
	while (CURRENT_Q)
	{
		if (CURRENT_Q->id == sId)
		{
			cout << endl << "Employee Id: " << CURRENT_Q->id << endl
				<< "First Name: " << CURRENT_Q->fName << endl
				<< "Last Name: " << CURRENT_Q->lName << endl
				<< "Positon: " << CURRENT_Q->position << endl
				<< "Phone Number: " << CURRENT_Q->pNo << endl;
			cout << "Please Entere New Data" << endl;
			cout << endl << "First Name: ";
			cin >> CURRENT_Q->fName;
			cout << endl << "Last Name: ";
			cin >> CURRENT_Q->lName;
			cout << endl << "Postion: ";
			cin >> CURRENT_Q->position;
			cout << endl << "Phone Number: ";
			cin >> CURRENT_Q->pNo;
			cout << endl << "The Employee's Details Have Been Updated." << endl;
			system("pause");
			return;
		}
		CURRENT_Q = CURRENT_Q->NEXT;
	}
	cout << endl << "There Is No Employee With Inserted ID " << endl;
	system("pause");
	return;
}
void Queue::displayEmployee()
{
	cout << endl << "---Display Employee---";
	CURRENT_Q = START_Q;
	if (START_Q == NULL)
	{
		cout << endl << "There Is No Employee To Display" << endl;
		system("pause");
		return;
	}
	while (CURRENT_Q)
	{
		cout << endl << CURRENT_Q->id << " / "
			<< CURRENT_Q->fName << " / "
			<< CURRENT_Q->lName << " / "
			<< CURRENT_Q->position << " / "
			<< CURRENT_Q->pNo;

		CURRENT_Q = CURRENT_Q->NEXT;
	}
	cout << endl;
	system("pause");
	return;
}
void Queue::searchEmoloyee()
{
	int sId;
	cout << endl << "---Update Employee---";
	cout << endl << "Please Insert The Id Of Employee To Search: ";
	cin >> sId;
	CURRENT_Q = START_Q;
	if (START_Q == NULL)
	{
		cout << endl << "There Is No Employee With Inserted ID " << endl;
		system("pause");
		return;
	}
	while (CURRENT_Q)
	{
		if (CURRENT_Q->id == sId)
		{
			cout << endl << "Employee Id: " << CURRENT_Q->id << endl
				<< "First Name: " << CURRENT_Q->fName << endl
				<< "Last Name: " << CURRENT_Q->lName << endl
				<< "Positon: " << CURRENT_Q->position << endl
				<< "Phone Number: " << CURRENT_Q->pNo << endl;

			system("pause");
			return;
		}
		CURRENT_Q = CURRENT_Q->NEXT;
	}
	cout << endl << "There Is No Employee With Inserted ID " << endl;
	system("pause");
	return;
}
void Queue::clearAllEmployee()
{
	CURRENT_Q = START_Q;
	if (START_Q == NULL)
	{
		cout << endl << "All Employees Are Removed" << endl;
		system("pause");
		return;
	}
	while (CURRENT_Q->NEXT)
	{
		START_Q = CURRENT_Q->NEXT;
		free(CURRENT_Q);
		CURRENT_Q = START_Q;
	}
	if (START_Q)
		free(START_Q);
	START_Q = CURRENT_Q = NULL;
	cout << endl << "All Employees Are Removed" << endl;
	system("pause");
	return;
}

Queue::~Queue()
{
	FILE* file = fopen("employee.txt", "w");
	CURRENT_Q = START_Q;
	while (CURRENT_Q)
	{
		fprintf(file, "%d@%s@%s@%s@%s", CURRENT_Q->id, CURRENT_Q->fName, CURRENT_Q->lName, CURRENT_Q->position, CURRENT_Q->pNo);
		CURRENT_Q = CURRENT_Q->NEXT;
	}
	fclose(file);
}
